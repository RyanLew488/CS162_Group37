/*********************************************************************
** Program name: main.cpp
** Assignment: Group Project
** Author: Group 37
** Date: May 1, 2018
** 
**
*********************************************************************/

#include "board.hpp"

int main()
{
    Board predPreyGame;

    predPreyGame.runGame();

    return 0;
}